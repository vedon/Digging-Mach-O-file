//
//  SymbolInfo.h
//  WebCore_Mach-O
//
//  Created by vedon on 7/22/15.
//  Copyright (c) 2015 vedon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SymbolInfo : NSObject
@property (copy,nonatomic) NSString *symbolName;
@property (assign,nonatomic) uint64_t symbolAddr;

- (id)initWithSymbolName:(NSString *)symbolName;
@end
