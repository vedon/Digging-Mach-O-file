//
//  InstructionInfo.h
//  WebCore_Mach-O
//
//  Created by vedon on 7/22/15.
//  Copyright (c) 2015 vedon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InstructionInfo : NSObject
@property (copy,nonatomic) NSString *mnemonic;
@property (copy,nonatomic) NSString *firParam;
@property (copy,nonatomic) NSString *secParam;
@property (copy,nonatomic) NSString *thiParam;
@property (assign,nonatomic) uint64_t instructionAddress;

- (id)initWithMnemonic:(NSString *)mnemonic opStr:(NSString *)opStr instructionAddr:(uint64_t)address;
@end
