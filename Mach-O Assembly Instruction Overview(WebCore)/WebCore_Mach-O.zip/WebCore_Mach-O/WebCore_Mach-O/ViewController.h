//
//  ViewController.h
//  WebCore_Mach-O
//
//  Created by vedon on 7/22/15.
//  Copyright (c) 2015 vedon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

