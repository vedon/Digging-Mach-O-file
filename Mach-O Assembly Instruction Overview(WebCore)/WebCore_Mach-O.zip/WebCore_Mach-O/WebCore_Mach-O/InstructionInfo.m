//
//  InstructionInfo.m
//  WebCore_Mach-O
//
//  Created by vedon on 7/22/15.
//  Copyright (c) 2015 vedon. All rights reserved.
//

#import "InstructionInfo.h"

@implementation InstructionInfo
- (id)initWithMnemonic:(NSString *)mnemonic opStr:(NSString *)opStr instructionAddr:(uint64_t)address
{
    self = [super init];
    if (self) {
        _mnemonic = mnemonic;
        NSArray *arr = [opStr componentsSeparatedByString:@","];
        if (arr.count) {
            _firParam = [arr objectAtIndex:0] ;
        }else
        {
            _firParam = nil;
        }
        if (arr.count > 1) {
            _secParam = [arr objectAtIndex:1];
            _secParam = [_secParam stringByReplacingOccurrencesOfString:@"#" withString:@""];
            _secParam = [_secParam stringByReplacingOccurrencesOfString:@"[" withString:@""];
        }else
        {
            _secParam = nil;
        }
        if (arr.count > 2) {
            _thiParam = [arr objectAtIndex:2];
            _thiParam = [_thiParam stringByReplacingOccurrencesOfString:@"#" withString:@""];
            _thiParam = [_thiParam stringByReplacingOccurrencesOfString:@"]" withString:@""];
        }else
        {
            _thiParam = nil;
        }
        
        _instructionAddress = address;
    }
    return self;
}
@end
